package com.example.springboot_ex7.Controller;

import com.example.springboot_ex7.Dto.ApiResponse;
import com.example.springboot_ex7.Model.User;
import com.example.springboot_ex7.Service.UserService;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import javax.swing.plaf.PanelUI;
import java.util.List;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @GetMapping("/get")
    public ResponseEntity getUser() {
        List<User> users = userService.getUser();
        return ResponseEntity.status(200).body(users);
    }

    @PostMapping("/add")
    public ResponseEntity addUser(@RequestBody @Valid User user, Errors errors){
        if (errors.hasErrors())
            return ResponseEntity.status(400).body(errors.getFieldError().getDefaultMessage());
        userService.addUser(user);
        return ResponseEntity.status(200).body(new ApiResponse("user added!"));
    }

    @PutMapping("/update/{index}")
    public ResponseEntity updateUser(@PathVariable Integer id,@RequestBody @Valid User user, Errors errors){
        if (errors.hasErrors())
            return ResponseEntity.status(400).body(errors.getFieldError().getDefaultMessage());
        userService.updateUser(id, user);
        return ResponseEntity.status(200).body(new ApiResponse("user updated!"));
    }

    @DeleteMapping("/delete/{id}")
    public String deleteUser(@PathVariable Integer id){ /// string / ResponseEntity
        userService.deleteUser(id);
        return "user deleted!";
    }

    @GetMapping("/byid/{id}")
    public ResponseEntity getUserById(@PathVariable Integer id ){
        User user = userService.getUserById(id);
        return ResponseEntity.status(200).body(user);
    }

    @GetMapping("/byemail")
    public ResponseEntity getByEmail(@RequestBody String email){
        User user = userService.getUserByEmail(email);
        return ResponseEntity.status(200).body(user);
    }
////
    @GetMapping("/check/{password}")
    public RequestBody getByUserNamePassword(@RequestBody String userName, @PathVariable String password){
        User user = userService.getUserByUserNamePassword(userName, password);
        return ResponseEntity.status(200).body(user);
    }

    @GetMapping("/byrole/{role}")
    public ResponseEntity getUserByRole(String role){
        return ResponseEntity.status(200).body(userService.getUserByRole(role));
    }

    @GetMapping("/byage/{age}")
    public ResponseEntity getUserByAge(@PathVariable Integer age){
        return ResponseEntity.status(200).body(userService.getUserByAge(age));
    }

}
