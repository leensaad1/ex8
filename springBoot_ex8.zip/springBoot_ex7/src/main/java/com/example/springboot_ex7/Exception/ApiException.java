package com.example.springboot_ex7.Exception;

public class ApiException extends RuntimeException {

    public ApiException (String message){
        super(message);
    }

}
