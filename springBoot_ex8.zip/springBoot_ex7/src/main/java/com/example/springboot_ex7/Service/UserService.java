package com.example.springboot_ex7.Service;

import com.example.springboot_ex7.Exception.ApiException;
import com.example.springboot_ex7.Model.User;
import com.example.springboot_ex7.Repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;

    public List<User> getUser(){
        return userRepository.findAll();
    }

    public void addUser(User user){
        userRepository.save(user);
    }

    public Boolean updateUser(Integer id , User user){
        User oldUser = userRepository.getById(id);
        if (oldUser == null) /////
            return false;

        oldUser.setId(user.getId());
        oldUser.setName(user.getName());
        oldUser.setUserName(user.getUserName());
        oldUser.setPassword(user.getPassword());
        oldUser.setEmail(user.getEmail());
        oldUser.setRole(user.getRole());
        oldUser.setAge(user.getAge());

        userRepository.save(oldUser);
        return true;
    }

    public Boolean deleteUser(Integer id){
        User user = userRepository.getById(id);
        if (user == null)
            return false;
        userRepository.delete(user);
        return true;
    }

    public User getUserById(Integer id){
        User user = userRepository.findUserById(id);
        if (user==null)
            throw new ApiException("wrong ID");
        return user;
    }

///
    public User getUserByEmail(String email){
        User user = userRepository.findUserByEmail(email);
        if (user==null)
            throw new ApiException("wrong email");
        return user;
    }
/////
    public List<User> getUserByAge(Integer age){
        return ;
    }

    public List<User> getUserByRole(String role){
        List<User> user = userRepository.findUserByRoleContaining(role);
        if (user==null)
            throw new ApiException("wrong role");
        return user;
    }


    public User getUserByUserNamePassword(String userName, String password){
        User user = userRepository.findUserByUserName(userName);
        if (!user.getPassword().equals(password))
            throw new ApiException("failed to log in");
        return user;
    }


}
