package com.example.springboot_ex7.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@Entity
@NoArgsConstructor
public class User {

    @NotNull (message = "id can't be null")
    @Id //primary key
    private Integer id;

    @NotEmpty(message = "name can't be empty")
    @Size(min = 4, message = "name must be more than 4 characters")
    private String name;

    @NotEmpty(message = "userName can't be empty")
    @Size(min = 4, message = "userName must be more than 4 characters")
    @Column(columnDefinition = "varchar(20) not null , unique") ///
    private String userName;

    @NotEmpty(message = "password can't be empty")
    private String password;

    @NotEmpty(message = "email can't be empty")
    @Email
    @Column(columnDefinition = "varchar(20) not null unique")
    private String email;

    @NotEmpty(message = "role can't be empty")
    @Column(columnDefinition = "varchar(5) check (role in (user , admin))")
    private String role;

    @NotNull(message = "age can't be null")
    private Integer age;

}
