package com.example.springboot_ex7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootEx7ApplicationTests {

    @Test
    void contextLoads() {
    }

}
